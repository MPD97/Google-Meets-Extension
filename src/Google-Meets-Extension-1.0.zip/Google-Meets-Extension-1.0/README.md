# Google-Meets-Extension

<p>Extension for switching between Default (Domyślne) input device to mix (miks) stereo.</p>
<br/>
<h1>Installation</h1>
<ul>
  <li>Import src folder into extension in your browser</li>
  <li>Join meetings in https://meet.google.com/</li>
  <li>Click extension icon</li>
</ul>
